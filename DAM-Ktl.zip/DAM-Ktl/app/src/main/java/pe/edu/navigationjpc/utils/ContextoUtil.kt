package pe.edu.navigationjpc.utils

import android.content.Context

object conttexto{
    lateinit var CONTEXTO_APPX: Context
}
